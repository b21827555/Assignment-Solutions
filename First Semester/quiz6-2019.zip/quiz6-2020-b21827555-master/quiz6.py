import sys
try :
    with open(sys.argv[2], "r" , encoding = "utf-8") as comparison :
        comp_list = [[x for x in i.strip("\n").split(" ")] for i in comparison.readlines()]
        try:
            count = -1
            with open(sys.argv[1], "r", encoding = "utf-8") as input :
                for i in input:
                    count += 1
                    try:
                        f_i = list(map(float, i.strip("\n").split(" ")))
                        liste = [x for x in range(int(f_i[2]), int(f_i[3] + 1)) if x % round(f_i[0]) == 0 and x % round(f_i[1]) != 0]
                        print("""------------
My results:             {}
Results to compare:     {}""".format(" ".join(list(map(str, liste))), " ".join(comp_list[count])))
                        assert comp_list[count] == list(map(str, liste))
                        print("Goool!!!")
                    except AssertionError:
                        print("AssertionError: results don't match.")
                    except ValueError:
                        print("------------\nValueError: only numeric input is accepted.\nGiven input: {}".format(
                            " ".join(i.strip("\n").split(" "))))
                    except IndexError:
                        print("------------\nIndexError: number of operands less than expected.\nGiven input: {}".format(
                            " ".join(i.strip("\n").split(" "))))
                    except ZeroDivisionError:
                        print("------------\nZeroDivisionError: You can't divide by 0.\nGiven input: {}".format(
                            " ".join(i.strip("\n").split(" "))))
        except IOError:
            print("IOError: cannot open %s" % (sys.argv[1]))
        except IndexError:
            print("IndexError: number of input files less than expected.")
except IndexError :
    print("IndexError: number of input files less than expected.")
except IOError:
    print("IOError: cannot open %s" % (sys.argv[2]))
except :
    print("kaBOOM: run for your life!")
finally :
    print("\n˜ Game Over ˜")
