import sys
x = int(sys.argv[1])
liste = [i for i in range(1,2 * int(sys.argv[1]) ,2)]
for i in liste :
    print("%{}s".format(x + i -1) %(i * "*"))
    x -=1
liste = liste[:-1]
liste.sort(reverse = True)
for i in liste :
    print("%{}s".format(x + i + 1) %(i * "*"))
    x +=1
