import sys
x = int(sys.argv[1])
n = 1
def diamond(x,n) :
    print("%{}s".format(abs(x-1) + n ) % (n * "*"))
    if x -1 > 0:
        n += 2
    else:
        n -= 2
    if x == -int(sys.argv[1]) +2 :
        return
    return diamond(x - 1, n)
diamond(x,n)
