# assignment5-2020-b21827555
assignment5-2020-b21827555 created by GitHub Classroom
python version 2.7
numpy 1.16.5
pandas 0.24.2
matplotlib 2.2.3
