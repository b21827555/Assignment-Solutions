from sys import *
lines_list = []
ID_set = set()
with open(argv[1], "r", encoding = "utf-8") as file :
    for i in file :
        if not i.endswith("\n") :
            i += "\n"
        i = i.split("\t")
        i[0:2] = map(int, i[0:2])
        ID_set.add(i[0])
        lines_list.append(i)
lines_list.sort()
list_ID = [x for x in ID_set]
list_ID.sort()
with open(argv[2], "w", encoding = "utf-8") as out_file :
    for i in list_ID :
        out_file.write("Message %d\n" % (list_ID.index(i) + 1))
        for line in lines_list :
            line[0:2] = map(str, line[0:2])
            if line[0] == str(i) :
                out_file.write("\t".join(line))
