from sys import *
set_input = argv[1]
liste = [n for n in set_input.split(",") if int(n) > 0][0::2]
x = 1
while 1:
    i = int(liste[x])
    i_copy = i
    if i_copy -1 < len(liste):
        while i_copy -1 < len(liste) :
            liste.pop(i_copy-1)
            i_copy += (i-1)
    else :
        break
    x += 1
print(" ".join(liste))
