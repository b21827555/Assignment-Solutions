from sys import *
x,n = int(argv[1]),int(argv[2])
print("{}^{} = {}".format(x, n, x ** n), end="")
liste = [j for j in str(x ** n)]
while len(liste) > 1 :
    plus, sum = " + ", 0
    for i in liste :
        sum += int(i)
    print(" =", plus.join(liste),"=", sum, end="")
    liste = [j for j in str(sum)]
print()