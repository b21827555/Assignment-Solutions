from sys import *
S = argv[1]
sum_of_all = 0
sum_of_even = 0
even_numbers = list()
for i in S.split(",") :
    i = int(i)
    if i >= 0 :
        sum_of_all += i
        if i % 2 == 0 :
            sum_of_even += i
            even_numbers.append(i)
print("Even Numbers: \"" , end= "")
for x in even_numbers :
    if x != even_numbers[-1] :
        print(x , end = ",")
    else :
        print(str(x) + "\"")
print("Sum of Even Numbers: " + str(sum_of_even))
print("Even Number Rate: " + str(round(sum_of_even / sum_of_all, 3)))
