from sys import *
a = float(argv[1])
b = float(argv[2])
c = float(argv[3])
discriminant = pow(b,2) - 4 * a * c
x1 = (-b + pow(discriminant, 1 / 2)) / (2 * a)
x2 = (-b - pow(discriminant, 1 / 2)) / (2 * a)
if discriminant < 0 :
    print("There is no real solution")
elif discriminant == 0 :
    print("""There is a repeated real number solution
Solution(s): {:.2f}""".format(x1))
else :
    print("""There are two solutions
Solution(s): {:.2f} {:.2f}""".format(x1,x2))
