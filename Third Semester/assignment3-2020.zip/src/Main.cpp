#include <iostream>
#include "Stack.h"
#include "Truck.h"
#include "Station.h"
#include "FileIO.h"
int main(int argc, char** argv) {

    FileIO file(argv[1],argv[2],argv[3],argv[4],argv[5]) ;

    return 0;

}
