import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

public class ConstituteCollections {
  public static LastNameComparator comparator = new LastNameComparator();
  public static ArrayList<Contact> arrayList = new ArrayList<Contact>();
  public static TreeSet<Contact> treeSet = new TreeSet<Contact>();
  public static TreeSet<Contact> OrderedTreeSet = new TreeSet<Contact>(comparator) ;
  public static HashSet<Contact> hashSet = new HashSet<Contact>();
  public static HashMap<String,Contact> hashMap = new HashMap<String,Contact>();
  

    public ConstituteCollections(String path) throws IOException {
        reader(path);
        writer();    
    }
  
  public static void fillCollections(Contact contact){
      arrayList.add(contact);
      treeSet.add(contact);
      OrderedTreeSet.add(contact);
      hashMap.put(contact.getPhoneNumber(), contact);
      hashSet.add(contact);
  } 
  
      public void writer() throws IOException{
        // Writes contacts into the txt files.
        PrintWriter writer;
        FileWriter file;
        file = new FileWriter("contactsArrayList.txt",false);
        for (Contact a: arrayList){
        writer = new PrintWriter(file,true);
        writer.println(a.getContactInfo());
        }
        
        file = new FileWriter("contactsArrayListOrderByLastName.txt",false);
        Collections.sort(arrayList, comparator);
        for (Contact b: arrayList){
        writer = new PrintWriter(file,true);
        writer.println(b.getContactInfo());
        }
        
        file = new FileWriter("contactsHashSet.txt",false);
        for (Contact c: hashSet){
        writer = new PrintWriter(file,true);
        writer.println(c.getContactInfo());
        }
        
        file = new FileWriter("contactsTreeSet.txt",false);
        for (Contact d : treeSet){
        writer = new PrintWriter(file,true);
        writer.println(d.getContactInfo());
        }
                
        file = new FileWriter("contactsTreeSetOrderByLastName.txt",false);
        for (Contact e: OrderedTreeSet){
        writer = new PrintWriter(file,true);
        writer.println(e.getContactInfo());
        }
                
        file = new FileWriter("contactsHashMap.txt",false);
        for (Contact f: hashMap.values()){
        writer = new PrintWriter(file,true);
        writer.println(f.getContactInfo());
        }
    }
      
        public void reader(String path) throws IOException {
        BufferedReader reader = null;
        Contact contact;
    try {
        FileReader file = new FileReader(path);
        reader = new BufferedReader(file);
        String line;
        String[] info;
        while ((line = reader.readLine()) != null) {
            info = line.replace("\n","").trim().split(" ");
            contact = new Contact(info[0], info[1], info[2], info[3]);
            fillCollections(contact);
        } 
    }
    catch (FileNotFoundException e ) {
        System.err.printf("No such a  %s file..\n", path);
        System.exit(0);
    }
    catch (IOException e){
        System.err.printf("Occurs an error while reading %s file..\n", path);
        System.exit(0);
    }    
    finally {
        if (reader != null) 
            reader.close(); 
    }
        }
}