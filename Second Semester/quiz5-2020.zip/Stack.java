import java.util.ArrayList;

public class Stack {
  private ArrayList<Integer> stack;

    public Stack() {
        stack = new ArrayList<Integer>() ;
        
    }
    public int pop() {
        return stack.remove(stack.size()-1);
    }
    public int top() {
        return stack.get(stack.size()-1);
    }
    public void push(int i) {
        stack.add(i);
    }
    public int size(){
        return stack.size();
    }
    public boolean isEmpty() {
        return stack.isEmpty();
    }
    public boolean isFull() {
        return stack.size() == 10;
    
    }
    
            
  
}
