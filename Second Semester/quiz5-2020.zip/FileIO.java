import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FileIO {
    private static boolean bool = false;
        public static ArrayList<Integer> reader(String path) throws IOException {
            BufferedReader reader = null;
            ArrayList<Integer> lines = new ArrayList<Integer>();
        try {
            FileReader file = new FileReader(path);
            reader = new BufferedReader(file);
            String line;
            while ((line = reader.readLine()) != null ) {
                line = line.replace("\n","").trim();
                if (! line.isEmpty()) {
                int newLine = Integer.valueOf(line);
                lines.add(newLine);
                }
            } 
        }
        catch (FileNotFoundException e ) {
            System.err.printf("No such a  %s file..\n", path);
            System.exit(0);
        }
        catch (IOException e){
            System.err.printf("Occurs an error while reading %s file..\n", path);
            System.exit(0);
        }    
        finally {
            if (reader != null) 
                reader.close(); 
        }
        return lines;
    }
        public static void writer(String line) throws IOException{
            FileWriter file = new FileWriter("octal.txt",bool);
            bool = true;
            PrintWriter writer = new PrintWriter(file,true);
            writer.println(line);
            }   
}
