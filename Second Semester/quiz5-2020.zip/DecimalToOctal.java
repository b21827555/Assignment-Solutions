import java.io.IOException;
import java.util.ArrayList;

public class DecimalToOctal {

    public static ArrayList<Integer> decimals;

    public DecimalToOctal(String path) throws IOException {
        decimals = FileIO.reader(path);
        displayOctal();
    }
    private void displayOctal() throws IOException {
        for (int decimal: decimals) {
            Stack stack = new Stack();
            int remain = -1;
            int division = 0;
            while (remain != 0 || division != 0) {
                remain = decimal % 8;
                decimal = decimal - remain;
                division = decimal/8;
                decimal = division;
                stack.push(remain);
            }
            String s = "";
            stack.pop();
            while (!stack.isEmpty()) {
                s = s.concat(Integer.toString(stack.pop()));              
                
            }
            FileIO.writer(s);
            
        }  
    
    }
}
