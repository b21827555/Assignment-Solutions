import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FileIO {
    public static ArrayList<String> Reader(String path) throws IOException {
            BufferedReader reader = null;
            ArrayList<String> lines = new ArrayList<String>();
        try {
            FileReader file = new FileReader(path);
            reader = new BufferedReader(file);
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line.trim().replace("\n",""));
            } 
        }
        catch (FileNotFoundException e) {
            System.err.printf("No such a  %s file..\n", path);
            System.exit(0);
        }
        catch (IOException e){
            System.err.printf("Occurs an error while reading %s file..\n", path);
            System.exit(0);
        }    
        finally {
            if (reader != null) 
                reader.close(); 
        }
        return lines;
    }
    
    public static void Writer() throws IOException {

        FileWriter file = new FileWriter("icehockey.txt", true);
        PrintWriter writer = new PrintWriter(file,true);
        for (int i = 1; i < Match.hockeys.size()+1; i++) {
            String x = String.valueOf(i);
            writer.println(x + ".\t"+Match.hockeys.get(i-1).Display());
        }
        file = new FileWriter("basketball.txt", true);
        
        PrintWriter writerx = new PrintWriter(file,true);
        for (int i = 1; i < Match.basket.size()+1; i++) {
            String x = String.valueOf(i);
            writerx.println(x + ".\t"+Match.basket.get(i-1).Display());
        }
        file = new FileWriter("handball.txt", true);
        writer = new PrintWriter(file,true);
        for (int i = 1; i < Match.handB.size()+1; i++) {
            String x = String.valueOf(i);
            writer.println(x+ ".\t"+Match.handB.get(i-1).Display());
        }
        file = new FileWriter("volleyball.txt", true);
        writerx = new PrintWriter(file,true);
        for (int i = 1; i < Match.volleyB.size()+1; i++) {
            String x = String.valueOf(i);
            writerx.println(x + ".\t"+Match.volleyB.get(i-1).Display());
        }     
        
    }
}