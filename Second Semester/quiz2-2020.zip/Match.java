import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Comparator;

public class Match {
    public static ArrayList<IceHockey> hockeys = new ArrayList<IceHockey>();
    public static ArrayList<Basketball> basket = new ArrayList<Basketball>();
    public static ArrayList<Handball> handB = new ArrayList<Handball>();
    public static ArrayList<Volleyball> volleyB = new ArrayList<Volleyball>() ;
    private static ArrayList<String> lines ;

    public Match(String path) throws IOException {
    lines = FileIO.Reader(path);
    for (String line:lines) {
        String[] words = line.replace(":","\t").split("\t");
        whichGame(words[0],words[1],words[3],words[4]);
        whichGame(words[0],words[2],words[4],words[3]);
    }
    FileIO.Writer();
    }
    
    
    public void whichGame(String chars,String team,String sFor,String gain){
        int intFor = Integer.valueOf(sFor);
        int intGain = Integer.valueOf(gain);
        boolean bool = true;
         switch (chars) {     
            case "I" :
                if (!hockeys.isEmpty()) {
                    for (IceHockey h : hockeys ) {
                        if (h.team.equals(team)) {
                            h.totalGoals(intFor,intGain);
                            bool = false;
                            break; }
                }}
                if (hockeys.isEmpty() || bool ){
                    IceHockey hockey = new IceHockey(team, intFor, intGain);
 
                    hockeys.add(hockey);
                    break;}
 
            case "V" :
                if (!volleyB.isEmpty()) {
                    for (Volleyball v : volleyB ) {
                    if (v.team.equals(team)) {
                        v.totalGoals(intFor,intGain);
                        bool = false;
                        break; }              
                }}
                if (volleyB.isEmpty() || bool){
                    Volleyball volley = new Volleyball(team, intFor, intGain);
                    volleyB.add(volley);
                    break;
                                    }         
            case "H" :
                if(!handB.isEmpty()) {
                    for (Handball h : handB ) {
                    if (h.team.equals(team)) {
                        h.totalGoals(intFor,intGain);
                        bool = false;
                        break; }              
                } }
                if (handB.isEmpty() ||bool) {
                    Handball hand = new Handball(team, intFor, intGain);
                    handB.add(hand);               
                }
                break;
            case "B" :
                if (!basket.isEmpty()) {
                for (Basketball b : basket ) {
                    if (b.team.equals(team)) {
                        b.totalGoals(intFor,intGain);
                        bool = false;
                        break; }              
                }} 
                if (basket.isEmpty() || bool) {
                    Basketball bBall = new Basketball(team, intFor, intGain);
                    basket.add(bBall);               
                }
                break;
        }
}       
}
