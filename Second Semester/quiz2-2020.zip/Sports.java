import java.util.ArrayList;

public class Sports {
    protected String team;
    protected int won = 0;
    protected int loss = 0;
    protected int tie = 0;
    protected int match = 0;
    protected int setsFor = 0;
    protected int setsAgainst = 0;
    protected int total = 0;
    
    protected void totalGoals(int sFor,int gain) {
        if ( sFor > gain){
            total += 2;
            won += 1; }
        else if (gain > sFor)
            loss += 1;
        setsFor += sFor;
        setsAgainst += gain;
        match += 1;             
    }
    
    public String Display() {
        return String.format("%s\t%s\t%s\t%s\t%s\t%s:%s\t%s",team,match,won,tie,
        loss,setsFor,setsAgainst,total);
    }
}
        
class IceHockey extends Sports{
    public IceHockey(String name,int sFor, int gain){
        team = name;
        totalGoals(sFor, gain);  
            }
    
    @Override
    public void totalGoals(int sFor,int gain) {
        if (sFor>gain) {
            total +=3;
            won +=1;
        }
        else if (sFor == gain) {
            total += 1;
            tie += 1;
        }
        else
            loss += 1;
        setsFor += sFor;
        setsAgainst += gain;
        match += 1;           
    }
}
class Handball extends Sports {

    public Handball(String name, int sFor,int gain) {
        team = name;
        totalGoals(sFor, gain);
    }
    @Override
    public void totalGoals(int sFor,int gain) {
        super.totalGoals(sFor, gain);
        if (sFor == gain) {
            total += 1;
            tie += 1;
        }

    }
}
class Basketball extends Sports {
    public Basketball(String name, int sFor,int gain) {
        team = name;
        super.totalGoals(sFor, gain);     
    }
}

class Volleyball extends Sports {

    public Volleyball(String name, int sFor,int gain) {
        team = name;
        totalGoals(sFor, gain);     
    }
    @Override
    protected void totalGoals(int sFor, int gain) {
        if (sFor == 3 && (gain == 0 || gain == 1)) {
            total += 3;
            won += 1;
        }
        else if (sFor == 3 && gain == 2) {
            total += 2;
            won +=1;
        }
        else if (gain== 3 && (sFor == 1 || sFor == 0))
            loss += 1;
        
        else if (sFor == 2 && gain == 3) {
            loss +=1;
            total +=1;
        }
        match += 1;
        setsAgainst += gain;
        setsFor += sFor;          
    }
}