public class Bus {
    
    private String plate ;
    private int seatCount ;
    private Seat[] seats ;
       
    public Bus(String plate,int seatCount) {
    this.plate = plate;
    this.seatCount = seatCount;
    this.seats = new Seat[seatCount];
    
    for(int i =0; i < seatCount ; i++){
        seats[i] = new Seat();
    }
    }
    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public int getSeatCount() {
        return seatCount;
    }


    public void setSeatCount(int seatCount) {
        this.seatCount = seatCount;
    }

    public Seat[] getSeats() {
        return seats;
    }

    public void setSeats(Seat[] seats) {
        this.seats = seats;
    } 
          
            
    public void bookseat(Passenger p, int seatID) {
        if (!seats[seatID-1].getStatus()) {
        this.seats[seatID-1].setSeatID(seatID);
        this.seats[seatID-1].setPassenger(p);
        this.seats[seatID-1].setStatus(true);
        System.out.println("---------------------------------------\n"
            + "The seat " + seatID + " is reserved for you !\n");     
        }
        else {
            System.out.println("\nThe seat you chose had been already reserved by someone !\n");
        }
        }
    
    public void printAllPassengers() {
        for(int i =0; i < seatCount ; i++){
            if(seats[i].getStatus()){
                System.out.println(seats[i].getPassenger().Display()  
                        + seats[i].Display() 
                        + "\n" + seats[i].getPassenger().getPhone().Display() );
                System.out.println("----------------------------------------");
            }
        }
    }
    public void printAllAvailableSeatIDs() {
        String s = "" ;
        System.out.println("Available Seats: ");
        for(int i =0; i < seatCount ; i++){
           if(!seats[i].getStatus()){
               s += String.valueOf(i+1) + ", " ;
           }
       }
        System.out.println(s.substring(0, s.length() -2));
    }
    public void search(String name, String surname) {
        for (int i = 0; i <= seatCount; i++) {
            if (i == seatCount) {
                System.out.println("There is no passenger has name " + name + " " + surname);    
            }
            else if (seats[i].getStatus()) { 
                if (seats[i].getPassenger().getName().equals(name.trim()) 
                    && seats[i].getPassenger().getSurname().equals(surname.trim())) {
                    System.out.println(seats[i].getPassenger().Display()  
                        + seats[i].getPassenger().getPhone().Display());
                        break ;
                        
            
            }
        }
            
                
        }
        
    
    }
}

class Phone {
    private String countrycode ;
    private String code ;
    private String number ;
    private String type ;
    
    
    public void Phone(String countrycode,String code,String number,String type) {
        this.countrycode = countrycode ;
        this.code = code ;
        this.number = number ;
        this.type = type ;
        }

    public void Phone(String code,String number,String type) {
        this.code = code ;
        this.number = number ;
        this.type = type ;
    }

    public String getCountrycode() {
        return countrycode;
    }


    public void setCountrycode(String countrycode) {
        if (countrycode.length() != 0) {
            this.countrycode = countrycode;
    }
        else {
            this.countrycode = "+90" ;
        }
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        if (number.length() == 7) {
        this.number = number;
        }
        else {
            System.out.println("Invalid Phone number..");
        }}

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String Display() {
            
        return  getType() + " Phone: "+ getCountrycode() + " " + getCode() + 
                " " + getNumber()  ;
    
    
    }              
    
}

class Passenger {
    private String name ;
    private String surname ;
    private String gender ;
    private Phone phone ;
    

    public void Passenger(String name,String surname,String gender,Phone phone) 
    {
        this.name = name ;
        this.surname = surname ;
        this.gender = gender ;
        this.phone = phone ;
        
        }

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getGender() {
        return gender;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }

    public Phone getPhone() {
        return phone;
    }

    public void setPhone(Phone phone) {
        this.phone = phone;
    }
    public String Display() {
        return getName() + " " + getSurname() + " (" + getGender() + ")\n" ;
    
    }
}
class Seat {
    
    private int seatID ;
    private boolean status ;
    private Passenger passenger ;

      

      
 
    public void Seat(int seatID, boolean status, Passenger passenger) {
        this.seatID = seatID ;
        this.status = status ;
        this.passenger = passenger;
   
    }
    
    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }
    


    public int getSeatID() {
        return seatID;
    }


    public void setSeatID(int seatID) {
        this.seatID = seatID;
    }

    public boolean getStatus() {
        return status;
    }


    public void setStatus(boolean status) {
        this.status = status;
     
    }
    public String Display() {
        String stat ;
        if (status) {
            stat = "Reserved" ;
        }
        else {
        stat = "Available" ;
        }
        return "Seat: " + getSeatID() + " Status : " + stat ;
    
    } 
    
}

        