
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        Bus bus = new Bus("06 HUBM 06",42) ;
        
          
        boolean bool = true ;
        while (bool) {
            Seat seat = new Seat() ;
            Phone phone = new Phone() ;
            Passenger passenger = new Passenger() ;
            
            System.out.println(" Menu\n" +
"1 Book a seat\n" +
"2 Display all passengers with their seat numbers\n" +
"3 Display all available seatIDs\n" +
"4 Search\n" +
"5 Exit");
            Scanner scan = new Scanner(System.in) ;
            System.out.print("Enter your choice: ");
            int choice = scan.nextInt() ;
            String dummy = scan.nextLine() ;

            String x ;
            switch (choice) {
                case 1 :
                    System.out.print("Enter seat ID: ");
                    int s_id = scan.nextInt() ;
                    seat.setSeatID(s_id) ;
                    
                    x = scan.nextLine() ;
                    
                    System.out.print("Enter Name: ");
                    String name = scan.nextLine() ;
                    passenger.setName(name.trim());        
                    
                    System.out.print("Enter Surname: ");
                    String surname = scan.nextLine() ;
                    passenger.setSurname(surname.trim());
                                  
                    System.out.print("Enter Gender: ");
                    String gender = scan.nextLine() ;
                    passenger.setGender(gender.trim());

                    
                    System.out.print("Enter CountryCode: ");
                    String c_code = scan.nextLine() ;
                    phone.setCountrycode(c_code.trim()) ;
                    
                    System.out.print("Enter Code: ") ;
                    String code = scan.nextLine() ; 
                    phone.setCode(code.trim()) ;
                     
                    String number = null ;
                    do {
                    System.out.print("Enter Phone number: ");
                    number = scan.nextLine().trim() ;
                    phone.setNumber(number);
                    } while (number.length() != 7) ;
                    
                    System.out.print("Enter Type of number: ");
                    String type = scan.nextLine() ; 
                    phone.setType(type.trim()); 
                    
                    passenger.setPhone(phone);                                     
                    bus.bookseat(passenger, s_id);
                    phone.Display() ;
                                          
                    break ;
                case 2 :
                    bus.printAllPassengers() ;
                    break ;
                case 3 :
                    bus.printAllAvailableSeatIDs() ;
                    break ;
                case 4 :
                    System.out.print("Enter Name: ") ;
                    name = scan.nextLine() ;
                    System.out.print("Enter Surname: ") ;
                    surname = scan.nextLine() ;
                    bus.search(name,surname) ;
                    break ;
                case 5 :
                    bool = false ;
                    break ;
                default :
                    System.out.println("Invalid choice..\nTry again");                            
            
            }
        
        
        }
        
                
    }
    
}
