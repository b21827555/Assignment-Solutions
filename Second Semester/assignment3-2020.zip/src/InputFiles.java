
import java.io.IOException;

public interface InputFiles {
    public void reader(String path) throws IOException;
}