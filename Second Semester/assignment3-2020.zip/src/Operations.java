public abstract class Operations extends Examination {
    private Examination examination; 

    public Examination getExamination() {
        return examination;
    }
    public void setExamination(Examination examination) {
        this.examination = examination;
    }
}