public abstract class Examination {
    public abstract String getInfo(); //returns all operations of the patient.
    public abstract int cost(); // returns cost of each opreations
}