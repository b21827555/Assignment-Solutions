public abstract class FullTime extends Employee{
    
    public FullTime(String name, String surname, String reg, String position, int start) {
        super(name, surname, reg, position, start);
    }   
}