import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
       new University(args[0],args[1]);
    }   
}