public abstract class Academician extends Personnel{
    public static final int BASE_SALARY = 2600;

    public Academician(String name, String surname, String reg, String posiiton, int start) {
        super(name, surname, reg, posiiton, start);
    }
}