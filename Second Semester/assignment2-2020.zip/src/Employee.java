public abstract class Employee extends Personnel{
    
    public Employee(String name, String surname, String reg, String position, int start) {
        super(name, surname, reg, position, start);
    }  
}